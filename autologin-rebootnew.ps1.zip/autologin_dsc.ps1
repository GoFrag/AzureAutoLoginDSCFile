﻿Configuration SetAutoLogon {

  Node localhost {
  
    Registry AutoAdminLogon {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'AutoAdminLogon'
      ValueData = '1'
      ValueType = 'Dword'
    }
    Registry DefaultUserName {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'DefaultUserName'
      ValueData = 'labviewbuild'
      ValueType = 'String'
    }
    Registry DefaultPassword {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'DefaultPassword'
        ValueData = 'Labview==='
        ValueType = 'String'
      }
    Registry DefaultDomain {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'DefaultDomain'
        ValueData = ''
        ValueType = 'String'
      }	
    }
  }

shutdown -r -f -t 120
