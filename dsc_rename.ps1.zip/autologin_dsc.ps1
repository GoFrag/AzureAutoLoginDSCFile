﻿Configuration SetAutoLogon {

  Node localhost {
  
    Registry AutoAdminLogon {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'AutoAdminLogon'
      ValueData = '1'
      ValueType = 'Dword'
    }
    Registry DefaultUserName {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'DefaultUserName'
      ValueData = 'labviewbuild'
      ValueType = 'String'
    }
    Registry DefaultPassword {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'DefaultPassword'
        ValueData = 'Labview==='
        ValueType = 'String'
      }
    Registry DefaultDomain {
      Ensure = 'Present'
      Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
      ValueName = 'DefaultDomain'
        ValueData = ''
        ValueType = 'String'
      }
      Registry ForceAutoLogon {
        Ensure = 'Present'
        Key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
        ValueName = 'ForceAutoLogon'
        ValueData = '1'
        ValueType = 'Dword'
      }		
    }

    net use \\labviewstore /user:apac\inlabview labview===
    .\powershell.exe -file \\labviewstore\TFS\Software\AzureAgentScripts\Rename-AzureVMHostName.ps1

  }
